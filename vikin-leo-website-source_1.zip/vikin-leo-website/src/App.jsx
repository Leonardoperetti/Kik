import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Music, Headphones, Mic, Settings, Play, Mail, Instagram, Youtube, Twitter } from 'lucide-react'
import bg1 from './assets/bg1.jpg'
import bg2 from './assets/bg2.jpg'
import bg3 from './assets/bg3.jpg'
import './App.css'

function App() {
  const [isScrolled, setIsScrolled] = useState(false)

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const services = [
    {
      icon: Music,
      title: "Composição Instrumental",
      description: "Criação de trilhas sonoras originais e cativantes que se alinham perfeitamente à visão do artista. Desde batidas eletrônicas pulsantes até melodias orquestrais complexas.",
      color: "from-purple-500 to-pink-500"
    },
    {
      icon: Headphones,
      title: "Mix e Master",
      description: "Técnicas avançadas de mixagem para equilibrar todos os elementos da sua música, garantindo clareza, profundidade e impacto. Masterização que otimiza o som para diferentes plataformas.",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Mic,
      title: "Produção Musical Completa",
      description: "Serviço abrangente que acompanha o artista desde a concepção inicial da ideia até a entrega final da faixa pronta. Arranjo, gravação, edição, mixagem e masterização.",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Settings,
      title: "Direção Técnica Musical",
      description: "Suporte especializado para projetos que exigem supervisão artística e técnica aprofundada. Orientação na estruturação de performances e otimização do som.",
      color: "from-orange-500 to-red-500"
    }
  ]

  const portfolio = [
    {
      title: "EP Autoral",
      description: "6 músicas produzidas desde o instrumental até o audiovisual",
      type: "Produção Completa",
      year: "2024"
    },
    {
      title: "Colaboração KONDZILLA",
      description: "Produção musical e audiovisual para grande produtora",
      type: "Colaboração",
      year: "2024"
    },
    {
      title: "Música com 3 Artistas",
      description: "Harmonização de diferentes estilos e visões artísticas",
      type: "Produção",
      year: "2023"
    },
    {
      title: "Fred P (Black Jazz Consortium)",
      description: "Participação como violonista em 2 faixas de música eletrônica",
      type: "Colaboração",
      year: "2023"
    },
    {
      title: "Ever Bronco",
      description: "Criação de harmonias para múltiplas músicas do artista",
      type: "Arranjos",
      year: "2023"
    }
  ]

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-background/80 backdrop-blur-md border-b border-border' : 'bg-transparent'}`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold glow-text">Vikin Léo</h1>
            <div className="hidden md:flex space-x-6">
              <a href="#home" className="hover:text-primary transition-colors">Início</a>
              <a href="#about" className="hover:text-primary transition-colors">Sobre</a>
              <a href="#services" className="hover:text-primary transition-colors">Serviços</a>
              <a href="#portfolio" className="hover:text-primary transition-colors">Portfólio</a>
              <a href="#contact" className="hover:text-primary transition-colors">Contato</a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        <div 
          className="absolute inset-0 parallax-bg"
          style={{
            backgroundImage: `url(${bg1})`,
          }}
        />
        <div className="absolute inset-0 hero-gradient" />
        <div className="relative z-10 text-center px-4">
          <h1 className="text-6xl md:text-8xl font-bold mb-6 glow-text">
            Vikin Léo
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-muted-foreground max-w-2xl mx-auto">
            Produtor Musical e Artista Multifacetado
          </p>
          <div className="music-wave h-2 w-64 mx-auto mb-8 rounded-full" />
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground">
            <Play className="mr-2 h-5 w-5" />
            Ouça Meu Trabalho
          </Button>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="container mx-auto max-w-4xl">
          <h2 className="text-4xl font-bold text-center mb-12 glow-text">Sobre</h2>
          <Card className="card-hover bg-card/50 backdrop-blur-sm border-border">
            <CardContent className="p-8">
              <p className="text-lg leading-relaxed text-center">
                Vikin Léo é um produtor musical e artista multifacetado, com uma paixão inabalável por transformar ideias em experiências sonoras memoráveis. Com anos de experiência e um ouvido apurado para a inovação, Vikin Léo se destaca no cenário musical por sua habilidade em navegar por diversos gêneros e estilos, sempre entregando produções de alta qualidade e com uma identidade única. Seja na criação de instrumentais envolventes, na lapidação de faixas através da mixagem e masterização, ou na direção técnica de projetos complexos, seu trabalho é sinônimo de excelência e criatividade.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 px-4 relative">
        <div 
          className="absolute inset-0 parallax-bg opacity-20"
          style={{
            backgroundImage: `url(${bg2})`,
          }}
        />
        <div className="container mx-auto relative z-10">
          <h2 className="text-4xl font-bold text-center mb-12 glow-text">Serviços</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <Card key={index} className="card-hover bg-card/80 backdrop-blur-sm border-border">
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg bg-gradient-to-r ${service.color} flex items-center justify-center mb-4`}>
                    <service.icon className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{service.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground">
                    {service.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="py-20 px-4">
        <div className="container mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12 glow-text">Portfólio</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {portfolio.map((project, index) => (
              <Card key={index} className="card-hover bg-card/80 backdrop-blur-sm border-border">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <Badge variant="secondary">{project.type}</Badge>
                    <span className="text-sm text-muted-foreground">{project.year}</span>
                  </div>
                  <CardTitle className="text-xl">{project.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-muted-foreground">
                    {project.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4 relative">
        <div 
          className="absolute inset-0 parallax-bg opacity-30"
          style={{
            backgroundImage: `url(${bg3})`,
          }}
        />
        <div className="container mx-auto max-w-4xl relative z-10">
          <h2 className="text-4xl font-bold text-center mb-12 glow-text">Contato</h2>
          <Card className="card-hover bg-card/80 backdrop-blur-sm border-border">
            <CardContent className="p-8 text-center">
              <p className="text-lg mb-8">
                Pronto para elevar sua música a um novo patamar? Entre em contato e vamos criar algo incrível juntos.
              </p>
              <div className="flex justify-center space-x-4 mb-8">
                <Button variant="outline" size="lg">
                  <Mail className="mr-2 h-5 w-5" />
                  Email
                </Button>
                <Button variant="outline" size="lg">
                  <Instagram className="mr-2 h-5 w-5" />
                  Instagram
                </Button>
                <Button variant="outline" size="lg">
                  <Youtube className="mr-2 h-5 w-5" />
                  YouTube
                </Button>
                <Button variant="outline" size="lg">
                  <Twitter className="mr-2 h-5 w-5" />
                  Twitter
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="container mx-auto text-center">
          <p className="text-muted-foreground">
            © 2024 Vikin Léo. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  )
}

export default App

